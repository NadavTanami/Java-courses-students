public class Classroom {
    private String building;
    private String roomNumber;
    private int seats;

//constructor
    public Classroom(String building, String roomNumber, int seats){
        if (seats < 30) {
            throw new ClassroomTooSmallException("מספר המקומות בכיתה קטן מדי (לפחות 30)");
        }
        this.building = building;
        this.roomNumber = roomNumber;
        this.seats = seats;
    }
//get to all
    public String getBuilding() {
        return building;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public int getSeats() {
        return seats;
    }
//set to all
    public void setBuilding(String building) {
        this.building = building;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }
}
