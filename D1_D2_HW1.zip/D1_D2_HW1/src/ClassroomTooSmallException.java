public class ClassroomTooSmallException extends RuntimeException {
    public ClassroomTooSmallException(String message) {
        super(message);
    }
}
