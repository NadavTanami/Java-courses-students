import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CollectionUtils {
    public static <T extends Comparable<T>> T max(List<T> list){
        T max = list.get(0);
        for (T t : list){
            if (max.compareTo(t) < 0){
                max = t;
            }
        }
        return max;
    }

    public static <T> List<T> findDuplicates(List<T> list) {
        List<T> duplicates = new ArrayList<>();
        Set<T> seen = new HashSet<>();

        for (T item : list) {
            if (!seen.add(item) && !duplicates.contains(item)) {
                duplicates.add(item);
            }
        }
        return duplicates;

    }
}
