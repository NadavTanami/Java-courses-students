import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Course implements Serializable {
    private String code;
    private String title;
    private int creditPoints;
    private int capacity;
    private List<Course> prerequisites;

    //constructor
    public Course(String code, String title, int creditPoints, int capacity)
            throws CapacityTooSmallException {
        if (capacity < 10) {
            throw new CapacityTooSmallException("קיבולת הקורס קטנה מדי (לפחות 10)");
        }
        this.code = code;
        this.title = title;
        this.creditPoints = creditPoints;
        this.capacity = capacity;
        this.prerequisites = (prerequisites != null) ? prerequisites : new ArrayList<>();
    }
    // כאן המימוש של המתודה שאתה שואל עליה:
    public boolean hasPrerequisite(Course c) {
        return prerequisites.contains(c);
    }
    public String getCode(){
        return code;
    }
    public String getTitle(){
        return title;
    }
    public String setCode(){
        return code;
    }
    public String setTitle(){
        return title;
    }

    public List<Course> getPrerequisites() {
        return prerequisites;
    }

    public void setPrerequisites(List<Course> prerequisites) {
        this.prerequisites = prerequisites;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getCreditPoints() {
        return creditPoints;
    }

    public void setCreditPoints(int creditPoints) {
        this.creditPoints = creditPoints;
    }
    public void addPrerequisite(Course c){
        if(!this.prerequisites.contains(c))
            this.prerequisites.add(c);
        else System.out.println("Course already in prerequisites");
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return creditPoints == course.creditPoints && capacity == course.capacity && Objects.equals(code, course.code) && Objects.equals(title, course.title) && Objects.equals(prerequisites, course.prerequisites);
    }

    @Override
    public int hashCode() {
        return Objects.hash(code, title, creditPoints, capacity, prerequisites);
    }
}

