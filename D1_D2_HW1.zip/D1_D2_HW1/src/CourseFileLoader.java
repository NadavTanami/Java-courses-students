import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class CourseFileLoader {
    public List<Course> load (String filePath) throws IOException, BadFormatException, CapacityTooSmallException {
        List<Course> courses = new ArrayList<>();
        Map<String, Course> courseMap = new HashMap<>();
        Map<Course, List<String>> prerequisitesMap = new HashMap<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String code = null, title = null, prerequisites = null;
            int credits = 0, capacity = 0;

            String line;
            while ((line = reader.readLine()) != null) {
                String[] spl = line.split(":");

                if (spl.length < 2) {
                    throw new BadFormatException("Bad format: missing value");
                }

                switch (spl[0]) {
                    case "CODE":
                        code = spl[1].trim();
                        break;
                    case "TITLE":
                        title = spl[1].trim();
                        break;
                    case "CREDITS":
                        try {
                            credits = Integer.parseInt(spl[1].trim());
                        } catch (NumberFormatException e) {
                            throw new BadFormatException("Invalid number format for credits");
                        }
                        break;
                    case "CAPACITY":
                        try {
                            capacity = Integer.parseInt(spl[1].trim());
                        } catch (NumberFormatException e) {
                            throw new BadFormatException("Invalid number format for capacity");
                        }
                        break;
                    case "PREREQUISITES":
                        prerequisites = spl[1].trim();
                        break;
                    default:
                        throw new BadFormatException("Unknown property: " + spl[0]);
                }

                if (code != null && title != null && capacity > 0) {
                    Course course = new Course(code, title, credits, capacity);
                    courses.add(course);
                    courseMap.put(code, course);

                    if (prerequisites != null) {
                        prerequisitesMap.put(course, Arrays.asList(prerequisites.split(",")));
                    }

                    // Reset values for the next course
                    code = title = prerequisites = null;
                    credits = capacity = 0;
                }
            }
        }

        // Process prerequisites now that all courses exist
        for (Map.Entry<Course, List<String>> entry : prerequisitesMap.entrySet()) {
            Course course = entry.getKey();
            for (String preReqCode : entry.getValue()) {
                Course prerequisite = courseMap.get(preReqCode.trim());
                if (prerequisite != null) {
                    course.addPrerequisite(prerequisite);
                } else {
                    throw new BadFormatException("Prerequisite course not found: " + preReqCode);
                }
            }
        }

        return courses;
    }
}

