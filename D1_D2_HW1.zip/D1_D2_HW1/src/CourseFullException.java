public class CourseFullException extends EnrollmentException{
    public CourseFullException(String message) {
        super(message);
    }
}
