public class DuplicateEnrollmentException extends EnrollmentException{
    public DuplicateEnrollmentException(String message) {
        super(message);
    }
}
