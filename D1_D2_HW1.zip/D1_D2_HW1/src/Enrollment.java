import java.time.LocalDateTime;
import java.io.Serializable;


public class Enrollment implements Serializable{
    private Student student;
    private Course course;
    private LocalDateTime timestamp;

    //constructor
    public Enrollment(Student student, Course course, LocalDateTime timestamp){
        this.student = student;
        this.course = course;
        this.timestamp = timestamp;
    }

    public Course getCourse() {
        return course;
    }

    public Student getStudent() {
        return student;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setCourse(Course course) {
        this.course = course;
    }

    public void setStudent(Student student) {
        this.student = student;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }


    @Override
    public String toString() {
        return "Enrollment{" +
                "student=" + student +
                ", course=" + course +
                ", timestamp=" + timestamp +
                '}';
    }
}
