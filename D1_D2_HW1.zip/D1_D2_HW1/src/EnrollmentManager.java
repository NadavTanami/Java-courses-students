import java.util.ArrayList;
import java.util.List;

public class EnrollmentManager {
    private List<Enrollment> enrollments = new ArrayList<>();

    public void enroll(Student s, Course c) throws
            CourseFullException,
            PrerequisiteMissingException,
            DuplicateEnrollmentException{
        //בדיקה אם הסטודנט רשום
        for(Enrollment e : enrollments){
            if(e.getStudent().equals(s) && e.getCourse().equals(c)){
                throw new DuplicateEnrollmentException("הסטודנט כבר רשום לקורס הזה!");
            }
        }
        //בדיקת קורסים מקדימים
        for (Course prereq : c.getPrerequisites()) {
            boolean hasIt = false;
            for (Enrollment e : enrollments) {
                if (e.getStudent().equals(s) && e.getCourse().equals(prereq)) {
                    hasIt = true;
                    break;
                }
            }
            if (!hasIt) {
                throw new PrerequisiteMissingException("חסר קורס מקדים: " + prereq.getCode());
            }
        }

        //בדיקה אם הקורס מלא
        long enrolledCount = enrollments.stream()
                .filter(e -> e.getCourse().equals(c))
                .count();
        if (enrolledCount >= c.getCapacity()) {
            throw new CourseFullException("הקורס מלא");
        }
        // אם הכול תקין — צור רישום חדש
        Enrollment newEnrollment = new Enrollment(s, c, java.time.LocalDateTime.now());
        enrollments.add(newEnrollment);
    }

    public List<Enrollment> getAllEnrollments() {
        return enrollments;
    }
}
