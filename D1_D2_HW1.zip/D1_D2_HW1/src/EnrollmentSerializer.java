import java.io.*;
import java.util.List;

public class EnrollmentSerializer {
    public static void save(List<Enrollment> enrollments, String filePath)
        throws IOException{
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(enrollments);
        }
    }
    public static List<Enrollment> load(String path) throws IOException, ClassNotFoundException{
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(path))){
            return (List<Enrollment>) ois.readObject();
        }
    }
}
