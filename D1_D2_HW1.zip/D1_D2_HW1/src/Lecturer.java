import java.util.List;

public class Lecturer extends Person{
    private String department;
    private List<Course> teaches;

    public Lecturer(String id, String name, String department){
        super(id, name);
        this.department = department;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public List<Course> getTeaches() {
        return teaches;
    }

    public void setTeaches(List<Course> teaches) {
        this.teaches = teaches;
    }
}
