public class PrerequisiteMissingException extends EnrollmentException{
    public PrerequisiteMissingException(String message) {
        super(message);
    }
}
