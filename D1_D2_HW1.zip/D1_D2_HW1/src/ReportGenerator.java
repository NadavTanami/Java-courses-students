import java.io.*;
import java.util.List;

public class ReportGenerator {
    public static void writeEnrollmentReport(String filePath, List<Enrollment> enrollments)
        throws ReportWriteException{
        try (DataOutputStream dataOut = new DataOutputStream(new FileOutputStream(filePath))) {
            for (Enrollment enrollment : enrollments) {
                dataOut.writeUTF(enrollment.getStudent().getId() + " | "
                        + enrollment.getStudent().getName() + " | "
                        + enrollment.getCourse().getCode() + " | "
                        + enrollment.getTimestamp());
            }
        } catch (IOException e) {
            throw new ReportWriteException("Error writing report: " + e.getMessage());
        }


    }
}
