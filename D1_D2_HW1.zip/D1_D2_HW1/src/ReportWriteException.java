public class ReportWriteException extends RuntimeException {
    public ReportWriteException(String message) {
        super(message);
    }
}
