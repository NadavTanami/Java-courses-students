import java.time.LocalDateTime;

public class ScheduledCourse {
    private Course course;
    private Classroom classroom;
    private LocalDateTime dateTime;
}
