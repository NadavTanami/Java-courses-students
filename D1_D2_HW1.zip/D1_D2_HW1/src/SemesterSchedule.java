import java.util.List;

public class SemesterSchedule {
    private List<ScheduledCourse> scheduledCourses;
}
