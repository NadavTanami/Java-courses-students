import java.time.LocalDate;
import java.util.Objects;
import java.io.Serializable;

public class Student extends Person implements Serializable{
    private LocalDate enrollmentDate;

    //constructor
    public Student(String id, String name, LocalDate enrollmentDate) {
        super(id, name);
        this.enrollmentDate = enrollmentDate;
    }

    public LocalDate getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(LocalDate enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }

    @Override
    public String toString() {
        return "Student{" +
                "enrollmentDate=" + enrollmentDate +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return Objects.equals(enrollmentDate, student.enrollmentDate);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(enrollmentDate);
    }
}
