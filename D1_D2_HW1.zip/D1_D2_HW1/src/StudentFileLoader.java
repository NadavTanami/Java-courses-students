import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentFileLoader {
    public List<Student> load (String filePath) throws IOException, BadFormatException{
        List<Student> students = new ArrayList<>();
        String id = null, name = null, dateString = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] spl = line.split(":");
                if (spl.length < 2) {
                    throw new BadFormatException("Bad format: missing value in line: " + line);
                }

                switch (spl[0].trim()) {
                    case "ID":
                        if (id != null && name != null && dateString != null) {
                            students.add(new Student(id, name, LocalDate.parse(dateString)));
                        }
                        id = spl[1].trim();
                        name = null; dateString = null;
                        break;

                    case "Name":
                        String[] fullName = spl[1].split(" ");
                        name = String.join(" ",fullName);
                        System.out.println(name);
                        break;

                    case "Joined":
                        dateString = spl[1].trim();
                        break;

                    default:
                        throw new BadFormatException("Unknown property: " + spl[0]);
                }
            }

            if (id != null && name != null && dateString != null) {
                students.add(new Student(id, name, LocalDate.parse(dateString)));
            }
        }
        return students;
    }
}
